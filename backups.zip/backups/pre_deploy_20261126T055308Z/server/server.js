/*
 * Global Pilgrim — Secure Payout Service
 * --------------------------------------
 * WHY THIS FILE EXISTS
 * The console (index.html) is a static single file. Anything it can do, a user
 * can do by editing the JavaScript in DevTools. Therefore the console must never
 * hold provider secret keys and must never decide whether a withdrawal is
 * allowed. This service is the only place that:
 *   1. authenticates the operator,
 *   2. locks the wallet row in PostgreSQL,
 *   3. checks the spendable balance,
 *   4. debits the ledger,
 *   5. calls the payout aggregator,
 *   6. reconciles provider webhooks.
 *
 * Run:  cp .env.example .env  &&  npm install  &&  npm run migrate  &&  npm start
 */

'use strict';

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');
const { Pool } = require('pg');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '64kb' }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
  max: 10,
  idleTimeoutMillis: 30000
});

const FEES = {
  bank: Number(process.env.FEE_BANK_PCT || 0.1),
  swift: Number(process.env.FEE_SWIFT_PCT || 0.35),
  crypto: Number(process.env.FEE_CRYPTO_PCT || 0.2),
  paypal: Number(process.env.FEE_PAYPAL_PCT || 0.5),
  giftcard: Number(process.env.FEE_GIFTCARD_PCT || 1.0),
  bills: Number(process.env.FEE_BILLS_PCT || 0.3),
  sim: Number(process.env.FEE_SIM_PCT || 0.3)
};

const RAILS = new Set(Object.keys(FEES));

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const r2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

function reference(prefix) {
  const d = new Date();
  const ymd = `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}`;
  return `${prefix}-${ymd}-${crypto.randomInt(100000, 999999)}`;
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function requireAuth(req, res, next) {
  const header = req.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!process.env.ADMIN_API_TOKEN || !safeEqual(token, process.env.ADMIN_API_TOKEN)) {
    return res.status(401).json({ error: 'unauthorised' });
  }
  next();
}

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

class ProviderError extends Error {
  constructor(message, status = 502) { super(message); this.status = status; }
}

async function providerFetch(url, options = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 25000);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    const text = await res.text();
    let body;
    try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
    if (!res.ok) {
      throw new ProviderError(`${url} -> ${res.status} ${body.message || body.error || text.slice(0, 200)}`, res.status === 400 ? 422 : 502);
    }
    return body;
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------------------------------------------ */
/* provider adapters                                                   */
/* ------------------------------------------------------------------ */

async function flutterwaveBanks(country) {
  const body = await providerFetch(`https://api.flutterwave.com/v3/banks/${encodeURIComponent(country)}`, {
    headers: { Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}` }
  });
  return (body.data || []).map(b => ({ name: b.name, code: b.code, swift: b.swift_code || null }));
}

async function flutterwaveVerify(accountNumber, bankCode) {
  const body = await providerFetch('https://api.flutterwave.com/v3/accounts/resolve', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ account_number: accountNumber, account_bank: bankCode })
  });
  return { accountName: body.data && body.data.account_name, accountNumber: body.data && body.data.account_number };
}

async function flutterwaveTransfer({ amount, currency, accountNumber, bankCode, narration, reference: ref }) {
  const body = await providerFetch('https://api.flutterwave.com/v3/transfers', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      account_bank: bankCode,
      account_number: accountNumber,
      amount,
      currency,
      narration,
      reference: ref,
      callback_url: process.env.PUBLIC_WEBHOOK_URL ? `${process.env.PUBLIC_WEBHOOK_URL}/api/webhooks/flutterwave` : undefined
    })
  });
  return { providerRef: body.data && (body.data.id || body.data.reference), raw: body };
}

async function wiseTransfer({ amount, currency, accountName, iban, swift, reference: ref }) {
  if (!process.env.WISE_API_TOKEN) throw new ProviderError('WISE_API_TOKEN not configured', 503);
  const body = await providerFetch('https://api.transferwise.com/v1/transfers', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.WISE_API_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      targetAccount: iban,
      quoteUuid: ref,
      customerTransactionId: ref,
      details: { reference: ref, transferPurpose: 'verification.transfer' }
    })
  });
  return { providerRef: String(body.id || ref), raw: body };
}

async function paypalToken() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_SECRET;
  if (!id || !secret) throw new ProviderError('PAYPAL_CLIENT_ID / PAYPAL_SECRET not configured', 503);
  const host = process.env.PAYPAL_MODE === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
  const body = await providerFetch(`${host}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: 'Basic ' + Buffer.from(`${id}:${secret}`).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });
  return { token: body.access_token, host };
}

async function paypalPayout({ amount, currency, receiver, reference: ref }) {
  const { token, host } = await paypalToken();
  const body = await providerFetch(`${host}/v1/payments/payouts`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      sender_batch_header: { sender_batch_id: ref, email_subject: 'Global Pilgrim payout', email_message: 'Your payout has been processed.' },
      items: [{ recipient_type: 'EMAIL', amount: { value: Number(amount).toFixed(2), currency }, receiver, note: 'Global Pilgrim payout', sender_item_id: ref }]
    })
  });
  return { providerRef: body.batch_header && body.batch_header.payout_batch_id, raw: body };
}

async function reloadlyGiftCard({ amount, currency, brand, receiver, reference: ref }) {
  if (!process.env.RELOADLY_ACCESS_TOKEN) throw new ProviderError('RELOADLY_ACCESS_TOKEN not configured', 503);
  const body = await providerFetch('https://giftcards.reloadly.com/orders', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.RELOADLY_ACCESS_TOKEN}`,
      'Content-Type': 'application/json',
      Accept: 'application/com.reloadly.giftcards-v1+json'
    },
    body: JSON.stringify({
      productId: brand,
      quantity: 1,
      unitPrice: Number(amount).toFixed(2),
      customIdentifier: ref,
      senderName: 'Global Pilgrim',
      recipientEmail: receiver
    })
  });
  return { providerRef: String(body.orderId || body.transactionId || ref), raw: body };
}

async function vtpassBill({ amount, serviceID, billersCode, phone, reference: ref }) {
  if (!process.env.VTPASS_API_KEY) throw new ProviderError('VTPASS_API_KEY not configured', 503);
  const body = await providerFetch('https://vtpass.com/api/pay', {
    method: 'POST',
    headers: { 'api-key': process.env.VTPASS_API_KEY, 'public-key': process.env.VTPASS_PUBLIC_KEY || '', 'secret-key': process.env.VTPASS_SECRET_KEY || '', 'Content-Type': 'application/json' },
    body: JSON.stringify({ request_id: ref, serviceID, billersCode, variation_code: 'default', amount, phone })
  });
  return { providerRef: body.requestId || (body.content && body.content.transactions && body.content.transactions.transactionId), raw: body };
}

async function cryptoTransfer({ amount, currency, address, network }) {
  const { ethers } = require('ethers');
  if (!process.env.RPC_URL || !process.env.CUSTODY_PRIVATE_KEY) throw new ProviderError('RPC_URL / CUSTODY_PRIVATE_KEY not configured', 503);
  const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
  const wallet = new ethers.Wallet(process.env.CUSTODY_PRIVATE_KEY, provider);
  if (!ethers.isAddress(address)) throw new ProviderError('invalid EVM address', 422);

  if (currency === 'USDT' && process.env.USDT_CONTRACT) {
    const abi = ['function transfer(address to, uint256 value) returns (bool)'];
    const token = new ethers.Contract(process.env.USDT_CONTRACT, abi, wallet);
    const units = ethers.parseUnits(Number(amount).toFixed(6), 6);
    const tx = await token.transfer(address, units);
    return { providerRef: tx.hash, raw: { hash: tx.hash, network } };
  }
  const tx = await wallet.sendTransaction({ to: address, value: ethers.parseEther(Number(amount).toFixed(18)) });
  return { providerRef: tx.hash, raw: { hash: tx.hash, network } };
}

async function executePayout(w) {
  switch (w.rail) {
    case 'bank':
      return flutterwaveTransfer({
        amount: w.amount, currency: w.currency, accountNumber: w.account_number,
        bankCode: w.bank_code, narration: w.narration || 'Global Pilgrim payout', reference: w.reference
      });
    case 'swift':
      return wiseTransfer({ amount: w.amount, currency: w.currency, accountName: w.account_name, iban: w.account_number, swift: w.bank_code, reference: w.reference });
    case 'crypto':
      return cryptoTransfer({ amount: w.amount, currency: w.currency, address: w.account_number, network: w.network });
    case 'paypal':
      return paypalPayout({ amount: w.amount, currency: w.currency, receiver: w.account_number, reference: w.reference });
    case 'giftcard':
      return reloadlyGiftCard({ amount: w.amount, currency: w.currency, brand: w.bank_code, receiver: w.account_number, reference: w.reference });
    case 'bills':
      return vtpassBill({ amount: w.amount, serviceID: w.bank_code, billersCode: w.account_number, phone: w.account_number, reference: w.reference });
    case 'sim':
      return vtpassBill({ amount: w.amount, serviceID: w.bank_code, billersCode: w.account_number, phone: w.account_number, reference: w.reference });
    default:
      throw new ProviderError('unsupported rail', 422);
  }
}

/* ------------------------------------------------------------------ */
/* routes                                                              */
/* ------------------------------------------------------------------ */

const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false });
app.use('/api/', apiLimiter);

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'global-pilgrim-payouts', time: new Date().toISOString() }));

app.get('/api/banks', requireAuth, asyncRoute(async (req, res) => {
  const country = String(req.query.country || 'NG').toUpperCase();
  const provider = String(req.query.provider || 'flutterwave').toLowerCase();
  if (provider !== 'flutterwave') return res.status(422).json({ error: 'only flutterwave bank catalogue is wired in this build' });
  const banks = await flutterwaveBanks(country);
  res.json({ country, provider, banks });
}));

app.post('/api/verify-account', requireAuth, asyncRoute(async (req, res) => {
  const { account_number, bank_code } = req.body || {};
  if (!/^\d{6,20}$/.test(String(account_number || ''))) return res.status(422).json({ error: 'invalid account_number' });
  if (!bank_code) return res.status(422).json({ error: 'bank_code required' });
  const data = await flutterwaveVerify(account_number, bank_code);
  if (!data.accountName) return res.status(422).json({ error: 'account could not be resolved' });
  res.json(data);
}));

app.get('/api/wallets/:owner', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pool.query('SELECT owner, currency, balance FROM wallets WHERE owner = $1', [req.params.owner]);
  res.json({ wallets: rows });
}));

app.get('/api/withdrawals', requireAuth, asyncRoute(async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM withdrawals ORDER BY created_at DESC LIMIT 100');
  res.json({ withdrawals: rows });
}));

/**
 * POST /api/withdrawals
 * Body: { owner, rail, provider, amount, currency, account_number, account_name,
 *         receiver_name, bank_code, bank_name, network, narration, idempotency_key }
 *
 * The balance check and debit happen inside one transaction with a row lock.
 * The provider call happens after commit; if it fails the withdrawal is marked
 * FAILED and the funds are returned by a compensating credit entry.
 */
app.post('/api/withdrawals', requireAuth, asyncRoute(async (req, res) => {
  const b = req.body || {};
  const rail = String(b.rail || '').toLowerCase();
  if (!RAILS.has(rail)) return res.status(422).json({ error: 'invalid rail' });
  const amount = r2(b.amount);
  if (!(amount > 0)) return res.status(422).json({ error: 'invalid amount' });
  if (!b.account_number || !b.receiver_name) return res.status(422).json({ error: 'account_number and receiver_name are required' });
  if (!b.idempotency_key) return res.status(422).json({ error: 'idempotency_key is required' });

  const feePct = FEES[rail];
  const fee = r2(amount * feePct / 100);
  const total = r2(amount + fee);
  const owner = String(b.owner || 'owner');
  const currency = String(b.currency || 'USD').toUpperCase();
  const ref = reference('PO');

  const client = await pool.connect();
  let created;
  try {
    await client.query('BEGIN');

    /* idempotency: a repeated request returns the original record */
    const dup = await client.query('SELECT * FROM withdrawals WHERE idempotency_key = $1', [b.idempotency_key]);
    if (dup.rows.length) {
      await client.query('ROLLBACK');
      return res.status(200).json({ withdrawal: dup.rows[0], idempotent: true });
    }

    const w = await client.query(
      'SELECT id, balance FROM wallets WHERE owner = $1 AND currency = $2 FOR UPDATE',
      [owner, currency]
    );
    if (!w.rows.length) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'wallet not found' }); }
    const wallet = w.rows[0];
    if (Number(wallet.balance) < total) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'insufficient_funds', balance: Number(wallet.balance), required: total });
    }

    await client.query('UPDATE wallets SET balance = balance - $1, updated_at = now() WHERE id = $2', [total, wallet.id]);
    const ins = await client.query(
      `INSERT INTO withdrawals
        (reference, idempotency_key, owner, rail, provider, currency, amount, fee,
         account_number, account_name, receiver_name, bank_code, bank_name, network, narration, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'PENDING')
       RETURNING *`,
      [ref, b.idempotency_key, owner, rail, b.provider || 'auto', currency, amount, fee,
        b.account_number, b.account_name || b.receiver_name, b.receiver_name,
        b.bank_code || null, b.bank_name || null, b.network || null, b.narration || null]
    );
    created = ins.rows[0];
    await client.query(
      `INSERT INTO ledger (reference, wallet_id, direction, amount, kind, note)
       VALUES ($1,$2,'DEBIT',$3,'WITHDRAWAL',$4)`,
      [ref, wallet.id, total, `${rail} payout to ${b.receiver_name}`]
    );
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  /* provider call outside the DB transaction */
  try {
    const result = await executePayout(created);
    const upd = await pool.query(
      `UPDATE withdrawals SET status = 'PROCESSING', provider_ref = $1, updated_at = now()
       WHERE id = $2 RETURNING *`,
      [result.providerRef ? String(result.providerRef) : null, created.id]
    );
    res.status(201).json({ withdrawal: upd.rows[0] });
  } catch (err) {
    /* compensating credit: the user must never lose funds on a failed payout */
    const c2 = await pool.connect();
    try {
      await c2.query('BEGIN');
      await c2.query('UPDATE withdrawals SET status = $1, failure_reason = $2, updated_at = now() WHERE id = $3', ['FAILED', String(err.message).slice(0, 400), created.id]);
      const wid = await c2.query('SELECT id FROM wallets WHERE owner = $1 AND currency = $2 FOR UPDATE', [owner, currency]);
      if (wid.rows.length) {
        await c2.query('UPDATE wallets SET balance = balance + $1, updated_at = now() WHERE id = $2', [total, wid.rows[0].id]);
        await c2.query(
          `INSERT INTO ledger (reference, wallet_id, direction, amount, kind, note)
           VALUES ($1,$2,'CREDIT',$3,'REVERSAL',$4)`,
          [ref, wid.rows[0].id, total, 'Provider failure reversal']
        );
      }
      await c2.query('COMMIT');
    } catch (e2) {
      await c2.query('ROLLBACK');
      console.error('reversal failed', e2);
    } finally {
      c2.release();
    }
    res.status(err.status || 502).json({ error: 'provider_failed', detail: err.message, reference: ref, reversed: true });
  }
}));

/* ---- provider webhooks: reconcile asynchronous settlement ---- */
app.post('/api/webhooks/flutterwave', asyncRoute(async (req, res) => {
  const sig = req.get('verif-hash');
  if (!process.env.FLUTTERWAVE_WEBHOOK_HASH || !safeEqual(sig, process.env.FLUTTERWAVE_WEBHOOK_HASH)) {
    return res.status(401).json({ error: 'invalid signature' });
  }
  const body = req.body || {};
  const ref = body.data && body.data.reference;
  const status = body.data && body.data.status;
  if (ref) {
    await pool.query(
      `UPDATE withdrawals SET status = $1, updated_at = now() WHERE reference = $2`,
      [status === 'SUCCESSFUL' ? 'SUCCESSFUL' : status === 'FAILED' ? 'FAILED' : 'PROCESSING', ref]
    );
  }
  res.json({ received: true });
}));

app.post('/api/webhooks/paypal', asyncRoute(async (req, res) => {
  /* Verify with PayPal's /v1/notifications/verify-webhook-signature in production. */
  const ref = req.body && req.body.resource && req.body.resource.batch_header && req.body.resource.batch_header.sender_batch_id;
  if (ref) await pool.query('UPDATE withdrawals SET status = $1, updated_at = now() WHERE reference = $2', ['PROCESSING', ref]);
  res.json({ received: true });
}));

app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

/* ---- errors ---- */
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: err.message || 'internal_error' });
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`Global Pilgrim payout service listening on :${port}`));

module.exports = app;
