-- Global Pilgrim payout service schema (PostgreSQL 14+)
-- The wallet row is the single source of truth for spendable balance.
-- Every withdrawal takes a row lock (SELECT ... FOR UPDATE) so two requests
-- can never spend the same funds, even if they arrive in the same millisecond.

CREATE TABLE IF NOT EXISTS wallets (
  id           BIGSERIAL PRIMARY KEY,
  owner        TEXT        NOT NULL,
  currency     TEXT        NOT NULL DEFAULT 'USD',
  balance      NUMERIC(20,8) NOT NULL DEFAULT 0 CHECK (balance >= 0),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner, currency)
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id             BIGSERIAL PRIMARY KEY,
  reference      TEXT        NOT NULL UNIQUE,
  idempotency_key TEXT       UNIQUE,
  owner          TEXT        NOT NULL,
  rail           TEXT        NOT NULL,
  provider       TEXT        NOT NULL,
  currency       TEXT        NOT NULL DEFAULT 'USD',
  amount         NUMERIC(20,8) NOT NULL CHECK (amount > 0),
  fee            NUMERIC(20,8) NOT NULL DEFAULT 0,
  account_number TEXT        NOT NULL,
  account_name   TEXT        NOT NULL,
  receiver_name  TEXT        NOT NULL,
  bank_code      TEXT,
  bank_name      TEXT,
  network        TEXT,
  narration      TEXT,
  status         TEXT        NOT NULL DEFAULT 'PENDING',
  provider_ref   TEXT,
  failure_reason TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ledger (
  id           BIGSERIAL PRIMARY KEY,
  reference    TEXT        NOT NULL,
  wallet_id    BIGINT      NOT NULL REFERENCES wallets(id),
  direction    TEXT        NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
  amount       NUMERIC(20,8) NOT NULL CHECK (amount > 0),
  kind         TEXT        NOT NULL,
  note         TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_owner ON withdrawals(owner, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ledger_wallet ON ledger(wallet_id, created_at DESC);
