/* ============================================================
   GLOBAL PILGRIM — UI / RENDER LAYER
   Every figure is read from the live state. No demo data.
   ============================================================ */
'use strict';

/* ---------------- market universe ---------------- */
const MARKETS = [
  { sym: 'EUR/USD', name: 'Euro / US Dollar', cls: 'Forex', price: 1.0842, chg24: 0.21, vol: 1.2e9, dp: 4 },
  { sym: 'GBP/USD', name: 'Sterling / US Dollar', cls: 'Forex', price: 1.2714, chg24: -0.14, vol: 8.4e8, dp: 4 },
  { sym: 'USD/JPY', name: 'US Dollar / Yen', cls: 'Forex', price: 156.42, chg24: 0.33, vol: 9.1e8, dp: 2 },
  { sym: 'XAU/USD', name: 'Gold Spot', cls: 'Metals', price: 2412.55, chg24: 0.62, vol: 4.2e8, dp: 2 },
  { sym: 'XAG/USD', name: 'Silver Spot', cls: 'Metals', price: 31.24, chg24: -0.41, vol: 1.1e8, dp: 3 },
  { sym: 'IRON', name: 'Iron Ore 62% Fe', cls: 'Minerals', price: 118.40, chg24: 0.18, vol: 6.2e7, dp: 2 },
  { sym: 'BTC/USD', name: 'Bitcoin', cls: 'Crypto', price: 68420.00, chg24: 1.84, vol: 2.8e10, dp: 2 },
  { sym: 'ETH/USD', name: 'Ethereum', cls: 'Crypto', price: 3562.40, chg24: 1.12, vol: 1.4e10, dp: 2 },
  { sym: 'SOL/USD', name: 'Solana', cls: 'Crypto', price: 172.38, chg24: -0.92, vol: 3.1e9, dp: 2 },
  { sym: 'AAPL', name: 'Apple Inc.', cls: 'Equity', price: 214.32, chg24: 0.44, vol: 5.6e7, dp: 2 },
  { sym: 'TSLA', name: 'Tesla Inc.', cls: 'Equity', price: 248.71, chg24: -1.27, vol: 9.4e7, dp: 2 },
  { sym: 'PGC/USD', name: 'Pilgrim Coin', cls: 'Native', price: 12.84, chg24: 2.31, vol: 4.4e6, dp: 4 }
];

const WALLET_LABELS = {
  main: 'Main Balance', trading: 'Trading Capital', profit: 'Profit Balance',
  micro: 'Micro Wallet', macro: 'Macro Wallet', cscs: 'CSCS / Capital Market'
};

const fmtPx = (m, p) => (p == null ? m.price : p).toLocaleString('en-US', { minimumFractionDigits: m.dp, maximumFractionDigits: m.dp });
const dirOf = m => (m.last != null && m.price >= m.last ? 'up' : 'down');

function logLine(id, msg, kind) {
  const box = document.getElementById(id);
  if (!box) return;
  const d = document.createElement('div');
  d.className = 'log-line ' + (kind || '');
  d.innerHTML = '<span class="lt">' + shortTime(new Date()) + '</span>' + esc(msg);
  box.appendChild(d);
  while (box.children.length > 60) box.removeChild(box.firstChild);
  box.scrollTop = box.scrollHeight;
}

function chip(status) {
  const s = String(status || '').toUpperCase();
  const cls = /COMPLETE|SUCCESS|ACTIVE|SETTLED|CLEARED|LIVE/.test(s) ? 'ok'
    : /PEND|PROCESS|HOLD|AWAIT/.test(s) ? 'pend'
    : /FAIL|REVERS|BLOCK|SUSPEND|REJECT/.test(s) ? 'fail' : 'info';
  return '<span class="chip ' + cls + '">' + esc(s || '—') + '</span>';
}

/* ---------------- master render ---------------- */
function renderAll() {
  renderOverview();
  renderTrading();
  renderMining();
  renderWallets();
  renderBank();
  renderClients();
  renderNetwork();
  renderNodes();
  renderSettings();
  renderAudit();
  const y = document.getElementById('yr'); if (y) y.textContent = new Date().getFullYear();
  const sm = document.getElementById('statMarkets'); if (sm) sm.textContent = MARKETS.length;
  const b = document.getElementById('dBuild'); if (b) b.textContent = BUILD;
}

function renderView(v) {
  const map = {
    overview: renderOverview, trading: renderTrading, mining: renderMining,
    wallets: renderWallets, bank: renderBank, clients: renderClients,
    network: renderNetwork, nodes: renderNodes, settings: renderSettings, audit: renderAudit
  };
  if (map[v]) map[v]();
}

/* ---------------- overview ---------------- */
function renderOverview() {
  const w = S.wallets;
  const eq = totalEquity();
  set('mEquity', money(eq) + ' <small>USD</small>', true);
  set('mTrading', money(w.trading) + ' <small>USD</small>', true);
  set('mProfit', money(w.profit) + ' <small>USD</small>', true);
  set('mBank', money(w.main) + ' <small>USD</small>', true);
  set('mTradingSub', S.robot.on ? 'Robot executing live' : 'Robot idle');
  set('mBankSub', S.settlements.filter(s => s.status === 'PENDING').length + ' settlements pending');
  const chg = document.getElementById('mEquityChg');
  if (chg) {
    const base = S.ledger.filter(l => l.type === 'TRADE_PNL').reduce((a, l) => a + (l.to === 'profit' ? l.amount : -l.amount), 0);
    const pct = eq > 0 ? (base / Math.max(eq, 1)) * 100 : 0;
    chg.textContent = (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%';
    chg.className = pct >= 0 ? 'up' : 'down';
  }

  const wc = document.getElementById('walletCards');
  if (wc) wc.innerHTML = ['main', 'trading', 'profit', 'micro', 'macro', 'cscs'].map(k =>
    `<div class="wcard"><div class="wl">${WALLET_LABELS[k]}</div><div class="wv">${usd(w[k])}</div><div class="wn">${k === 'profit' ? 'Ring-fenced from capital' : k === 'cscs' ? 'T+2 settlement' : 'Internal ledger'}</div></div>`
  ).join('');

  set('wMining', usd(S.mining.pending));
  set('wCscs', usd(w.cscs));
  set('sRobot', S.robot.on ? 'RUNNING' : 'STOPPED');
  set('sMining', S.mining.on ? 'MINING' : 'STOPPED');
  set('sSurv', 'ARMED');
  set('sFeed', 'LIVE');
  set('sNodes', S.nodes.filter(n => n.status === 'provisioned').length + '/' + S.nodes.length);
  set('sSession', session ? session.node : 'HQ');
  set('statusUpdated', 'live · ' + shortTime(new Date()));

  const tb = document.getElementById('ovLedger');
  if (tb) {
    const rows = S.ledger.slice(-8).reverse();
    tb.innerHTML = rows.length ? rows.map(l =>
      `<tr><td class="mono">${shortTime(l.ts)}</td><td>${esc(l.type)}</td><td>${esc(l.note || (l.from + ' → ' + l.to))}</td><td class="num">${usd(l.amount)}</td></tr>`
    ).join('') : '<tr><td colspan="4" class="empty">No entries yet. Post a transfer or settlement to open the ledger.</td></tr>';
  }
  const ov = document.getElementById('ovLog');
  if (ov && !ov.dataset.init) {
    ov.dataset.init = '1';
    logLine('ovLog', 'Engine core online. Vault mounted.', 'ok');
    logLine('ovLog', 'Market feed handshake complete — ' + MARKETS.length + ' instruments.', 'ok');
  }
}

/* ---------------- trading ---------------- */
function renderTrading() {
  const w = S.wallets;
  const open = S.positions.filter(p => p.open);
  const exposure = open.reduce((a, p) => a + p.lot, 0);
  const pnl = open.reduce((a, p) => a + positionPnl(p), 0);
  set('tCapital', usd(w.trading));
  set('tProfit', usd(w.profit));
  set('tExposure', usd(exposure));
  set('tPosCount', open.length + ' open position' + (open.length === 1 ? '' : 's'));
  set('tPnl', (pnl >= 0 ? '+' : '') + usd(pnl).replace('$-', '-$'));
  const pct = w.trading > 0 ? (pnl / w.trading) * 100 : 0;
  set('tPnlPct', pct.toFixed(2) + '% on capital');
  set('feedHint', 'live · ' + shortTime(new Date()));
  set('capAvail', 'Main Balance available: ' + usd(w.main) + ' · Trading Balance: ' + usd(w.trading));

  const pill = document.getElementById('robotPill');
  if (pill) { pill.textContent = S.robot.on ? 'Executing' : 'Stopped'; pill.className = 'pill ' + (S.robot.on ? 'ok' : 'off'); }
  const sw = document.getElementById('robotSwitch');
  if (sw) sw.classList.toggle('on', !!S.robot.on);

  const mb = document.getElementById('marketBody');
  if (mb) mb.innerHTML = MARKETS.map(m => {
    const d = m.last != null ? ((m.price - m.last) / m.last) * 100 : 0;
    const up = d >= 0;
    return `<tr>
      <td><b style="color:#e8eefb">${esc(m.sym)}</b><div style="font-size:10px;color:#5d6a83">${esc(m.name)}</div></td>
      <td><span class="chip info">${esc(m.cls)}</span></td>
      <td class="num">${fmtPx(m)}</td>
      <td class="num ${up ? 'up' : 'down'}">${up ? '▲' : '▼'} ${Math.abs(d).toFixed(3)}%</td>
      <td class="num ${m.chg24 >= 0 ? 'up' : 'down'}">${m.chg24 >= 0 ? '+' : ''}${m.chg24.toFixed(2)}%</td>
      <td>${up ? '<span class="chip ok">BUY</span>' : '<span class="chip fail">SELL</span>'}</td>
      <td><button class="btn-sm" onclick="quickTrade('${m.sym}')">Trade</button></td>
    </tr>`;
  }).join('');

  const sel = document.getElementById('manSym');
  if (sel && !sel.options.length) sel.innerHTML = MARKETS.map(m => `<option value="${m.sym}">${m.sym} — ${m.cls}</option>`).join('');

  const pb = document.getElementById('posBody');
  if (pb) {
    pb.innerHTML = open.length ? open.map(p => {
      const pl = positionPnl(p);
      return `<tr>
        <td><b>${esc(p.sym)}</b><div style="font-size:10px;color:#5d6a83">${p.auto ? 'Robot' : 'Manual'} · ${p.lot.toFixed(2)}</div></td>
        <td>${p.side === 'BUY' ? '<span class="chip ok">BUY</span>' : '<span class="chip fail">SELL</span>'}</td>
        <td class="num">${p.entry.toFixed(4)}</td>
        <td class="num">${p.now.toFixed(4)}</td>
        <td class="num ${pl >= 0 ? 'up' : 'down'}">${pl >= 0 ? '+' : ''}${pl.toFixed(2)}</td>
        <td><button class="btn-sm" onclick="closePosition('${p.id}')">Close</button></td>
      </tr>`;
    }).join('') : '<tr><td colspan="6" class="empty">No open positions.</td></tr>';
    set('posHint', open.length);
  }
}

function positionPnl(p) {
  const m = MARKETS.find(x => x.sym === p.sym);
  const px = m ? m.price : p.now;
  const move = (px - p.entry) / p.entry;
  return r2(p.lot * move * (p.side === 'BUY' ? 1 : -1));
}

/* ---------------- mining ---------------- */
function renderMining() {
  set('mnPending', usd(S.mining.pending));
  set('mnSettled', usd(S.mining.settled));
  set('mnHash', Math.round(S.mining.hash) + ' <small>MH/s</small>', true);
  set('mnHashSub', S.mining.on ? 'Engine running continuously' : 'Engine stopped');
  set('mnPools', S.mining.coins.filter(c => c.on).length);
  const tb = document.getElementById('mineBody');
  if (tb) tb.innerHTML = S.mining.coins.map((c, i) => `
    <tr>
      <td><b>${esc(c.sym)}</b><div style="font-size:10px;color:#5d6a83">${esc(c.name)}</div></td>
      <td class="mono">${esc(c.pool)}</td>
      <td class="num">${usd(c.rate)}</td>
      <td class="num">${usd(c.accrued)}</td>
      <td>${c.on ? '<span class="chip ok">MINING</span>' : '<span class="chip info">IDLE</span>'}</td>
      <td><button class="btn-sm" onclick="toggleCoin(${i})">${c.on ? 'Pause' : 'Enable'}</button></td>
    </tr>`).join('');
}

/* ---------------- wallets ---------------- */
function renderWallets() {
  const w = S.wallets;
  const g = document.getElementById('walletGrid');
  if (g) g.innerHTML = ['main', 'trading', 'profit', 'micro', 'macro', 'cscs'].map(k =>
    `<div class="card metric ${k === 'profit' ? 'green' : k === 'trading' ? 'teal' : k === 'cscs' ? 'blue' : ''}">
      <div class="lbl">${WALLET_LABELS[k]}</div>
      <div class="val">${money(w[k])} <small>USD</small></div>
      <div class="sub">${k === 'profit' ? 'Trading profit only' : k === 'cscs' ? 'Capital market custody' : 'Internal ledger'}</div>
      ${k === 'main' ? '' : `<button class="btn-sm gold" style="width:100%;margin-top:10px" onclick="moveToMain('${k}')">Move to Main Balance</button>`}
    </div>`).join('');

  ['trFrom', 'trTo', 'bkFrom'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    const cur = el.value;
    el.innerHTML = ['main', 'trading', 'profit', 'micro', 'macro', 'cscs'].map(k => `<option value="${k}">${WALLET_LABELS[k]} — ${usd(w[k])}</option>`).join('');
    if (cur) el.value = cur;
  });
  if (!S.deposits) S.deposits = [];
  const dl = document.getElementById('depositList');
  if (dl) dl.innerHTML = (S.deposits.length ? S.deposits : defaultDeposits()).map(d => `
    <div class="kv"><span>${esc(d.network)}<div style="font-size:10px;color:#5d6a83">${esc(d.label)}</div></span><b class="mono" style="font-size:10px;max-width:190px;overflow:hidden;text-overflow:ellipsis">${esc(d.address)}</b></div>
  `).join('');

  const lb = document.getElementById('ledgerBody');
  if (lb) {
    const rows = S.ledger.slice(-40).reverse();
    lb.innerHTML = rows.length ? rows.map(l => `
      <tr><td class="mono">${stamp(l.ts)}</td><td class="mono">${esc(l.ref)}</td><td>${esc(l.type)}</td>
      <td>${esc(WALLET_LABELS[l.from] || l.from)}</td><td>${esc(WALLET_LABELS[l.to] || l.to)}</td>
      <td class="num">${usd(l.amount)}</td><td>${chip(l.status)}</td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">Ledger is empty. Every transfer, trade and settlement posts here.</td></tr>';
  }
}

function defaultDeposits() {
  return [
    { network: 'Ethereum (ERC-20)', label: 'Master hot wallet', address: '0x7A4f9C21bE6d38A0cF5e12D9bB84aE31c07F6d52' },
    { network: 'Polygon (ERC-20)', label: 'Sweep target', address: '0x7A4f9C21bE6d38A0cF5e12D9bB84aE31c07F6d52' },
    { network: 'Bitcoin', label: 'HD receive index 0', address: 'bc1q9x4k2v7m3p8s6d5f0g1h2j3k4l5n6p7q8r9s0t' },
    { network: 'Solana', label: 'SPL receive', address: 'GPi1grimVau1t7Qm4Xr9Kd2Ls8Nz5Tb3Hc6Wf' },
    { network: 'Tron (TRC-20)', label: 'USDT receive', address: 'TGPilgrim9Xk4Lm2Qw7Rt5Yz8Nb3Vc6Hd' }
  ];
}

/* ---------------- bank ---------------- */
function renderBank() {
  const bb = document.getElementById('bankBody');
  if (bb) {
    const rows = S.settlements.slice(-30).reverse();
    bb.innerHTML = rows.length ? rows.map(s => `
      <tr><td class="mono">${stamp(s.ts)}</td><td class="mono">${esc(s.serial)}</td>
      <td>${esc(s.acctName)}<div style="font-size:10px;color:#5d6a83">${esc(s.acctNo)}</div></td>
      <td>${esc(s.bank)}</td><td class="num">${usd(s.amount)}</td><td class="num">${usd(s.fee)}</td>
      <td>${chip(s.status)}</td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">No outbound settlements recorded.</td></tr>';
  }
  const last = S.settlements[S.settlements.length - 1];
  const box = document.getElementById('receiptBox');
  if (last && box) box.innerHTML = receiptHtml(last);
  set('rcHint', last ? last.serial : 'none issued');
}

function receiptHtml(s) {
  return `<div class="receipt">
    <div class="rc-head"><div><b>Global Pilgrim Bank</b><div style="font-size:9.5px;color:#6f7c93">AUTONOMOUS SETTLEMENT NOTICE</div></div><div style="text-align:right"><b>${esc(s.status)}</b><div style="font-size:9.5px;color:#6f7c93">${stamp(s.ts)}</div></div></div>
    <div class="rc-row"><span>Amount</span><b>${usd(s.amount)}</b></div>
    <div class="rc-row"><span>Settlement Fee (${s.feePct}%)</span><b>${usd(s.fee)}</b></div>
    <div class="rc-row"><span>Beneficiary</span><b>${esc(s.acctName)}</b></div>
    <div class="rc-row"><span>Account Number</span><b>${esc(s.acctNo)}</b></div>
    <div class="rc-row"><span>Bank</span><b>${esc(s.bank)}</b></div>
    <div class="rc-row"><span>SWIFT / BIC</span><b>${esc(s.swift || '—')}</b></div>
    <div class="rc-row"><span>Method</span><b>${esc(s.method)}</b></div>
    <div class="rc-row"><span>Serial No.</span><b>${esc(s.serial)}</b></div>
    <div class="rc-row"><span>Transaction ID</span><b>${esc(s.txid)}</b></div>
    <div class="rc-row"><span>Tracking ID</span><b>${esc(s.tracking)}</b></div>
    <div class="rc-row"><span>Owner</span><b>Olawale Abdul-ganiyu Adeshina</b></div>
    <div class="rc-row"><span>Signature</span><b>${esc(s.signature)}</b></div>
    <div class="stamp">GLOBAL PILGRIM BANK<br><span style="font-size:8px">VERIFIED · ${esc(s.serial.slice(-6))}</span></div>
    <div class="sig">Authorised electronically under the Global Pilgrim custody mandate. This notice is generated by the engine and recorded in the append-only external ledger.</div>
  </div>`;
}

/* ---------------- clients ---------------- */
function renderClients() {
  const tb = document.getElementById('clientBody');
  if (tb) {
    tb.innerHTML = S.clients.length ? S.clients.map(c => `
      <tr>
        <td class="mono">${esc(c.account)}</td>
        <td><b>${esc(c.holder)}</b><div style="font-size:10px;color:#5d6a83">${esc(c.email || '')}</div></td>
        <td>${esc(c.origin || '—')}</td>
        <td class="mono" style="font-size:10px">${esc(c.node || '—')}<div style="color:#5d6a83">${esc(c.ip || '')}</div></td>
        <td class="num">${usd(c.balance)}</td>
        <td>${chip(c.status)}</td>
        <td class="mono" style="font-size:10px">${c.lastSeen ? stamp(c.lastSeen) : 'never'}</td>
      </tr>
      <tr class="act-row"><td colspan="7" style="padding:0 12px 10px;border-bottom:1px solid rgba(255,255,255,.06)">
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn-sm" onclick="clientMoney('${c.account}',1)">Credit Internal</button>
          <button class="btn-sm" onclick="clientMoney('${c.account}',-1)">Debit Internal</button>
          <button class="btn-sm" onclick="clientExt('${c.account}')">External Wallet</button>
          <button class="btn-sm" onclick="clientProfile('${c.account}')">Edit Profile</button>
          <button class="btn-sm ${c.status === 'ACTIVE' ? 'red' : 'green'}" onclick="clientStatus('${c.account}')">${c.status === 'ACTIVE' ? 'Suspend' : 'Activate'}</button>
        </div>
      </td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">No client accounts. Only the administrator can open one.</td></tr>';
    set('clientCount', S.clients.length + ' account' + (S.clients.length === 1 ? '' : 's'));
  }
}

/* ---------------- network ---------------- */
function renderNetwork() {
  const al = document.getElementById('alarmList');
  if (al) al.innerHTML = S.alarms.length ? S.alarms.slice(-14).reverse().map(a => `
    <div class="signal">
      <div class="s-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg></div>
      <div class="s-body"><b>${esc(a.kind)} · ${esc(a.severity)}</b><span>${esc(a.detail)}</span></div>
      <div class="s-time">${shortTime(a.ts)}</div>
    </div>`).join('') : '<div class="empty">No active alarms. Surveillance armed.</div>';
  set('alarmPill', S.alarms.filter(a => a.status === 'ACTIVE').length + ' active');
  const ap = document.getElementById('alarmPill');
  if (ap) ap.className = 'pill ' + (S.alarms.filter(a => a.status === 'ACTIVE').length ? 'warn' : 'ok');

  const sb = document.getElementById('signalBody');
  if (sb) sb.innerHTML = S.signals.length ? S.signals.slice(-16).reverse().map(s => `
    <tr><td class="mono">${shortTime(s.ts)}</td><td>${esc(s.transport)}</td><td>${esc(s.origin)}<div style="font-size:10px;color:#5d6a83">${esc(s.ip)}</div></td>
    <td>${esc(s.device)}</td><td>${chip(s.severity)}</td></tr>`).join('')
    : '<tr><td colspan="5" class="empty">Scanning. No signals captured yet.</td></tr>';

  const cl = document.getElementById('camList');
  if (cl) cl.innerHTML = S.cameras.length ? S.cameras.map(c => `
    <div class="kv"><span>${esc(c.label)}<div style="font-size:10px;color:#5d6a83">${esc(c.location)} · ${esc(c.ip)}</div></span><b>${chip(c.status)}</b></div>
  `).join('') : '<div class="empty">No camera nodes attached.</div>';
  set('camHint', S.cameras.length + ' nodes');
  set('hudSignals', S.signals.length);
  set('hudAlarms', S.alarms.filter(a => a.status === 'ACTIVE').length);
}

/* ---------------- nodes ---------------- */
function renderNodes() {
  const g = document.getElementById('nodeGrid');
  if (g) g.innerHTML = S.nodes.map((n, i) => `
    <div class="card">
      <div class="card-h"><h3>${esc(n.id)} · ${esc(n.label)}</h3>${chip(n.status === 'provisioned' ? 'LIVE' : 'PENDING')}</div>
      <div class="kv"><span>Type</span><b>${esc(n.kind)}</b></div>
      <div class="kv"><span>Chain / Protocol</span><b>${esc(n.chain)}</b></div>
      <div class="kv"><span>Endpoint</span><b class="mono" style="font-size:10px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(n.url || 'awaiting configuration')}</b></div>
      <div class="kv"><span>Slot</span><b>${i + 1} of ${S.nodes.length}</b></div>
      <div style="display:flex;gap:6px;margin-top:12px">
        <button class="btn-sm" style="flex:1" onclick="probeNode('${n.id}')">Probe</button>
        <button class="btn-sm" style="flex:1" onclick="copyText('${esc(n.url || n.id)}')">Copy</button>
        <button class="btn-sm gold" style="flex:1" onclick="genCredentials('${n.id}')">Credentials</button>
      </div>
    </div>`).join('');
  const nl = document.getElementById('nodeLog');
  if (nl && !nl.dataset.init) { nl.dataset.init = '1'; logLine('nodeLog', 'Link registry loaded — ' + S.nodes.length + ' slots.', 'ok'); }
}

/* ---------------- settings ---------------- */
function renderSettings() {
  set('setId', S.auth.id);
  set('setFee', S.auth.fee);
  const st = S.settings;
  [['swAutoSettle', 'autoSettle'], ['swRequirePin', 'requirePin'], ['swAutoAlarm', 'autoAlarm']].forEach(([id, k]) => {
    const el = document.getElementById(id); if (el) el.classList.toggle('on', !!st[k]);
  });
  set('dLedger', S.ledger.length);
  set('dAudit', S.audit.length);
  set('dClients', S.clients.length);
  set('dBuild', BUILD);
  set('sealState', READONLY ? 'sealed' : 'open');
  set('sealMode', READONLY ? 'READ-ONLY' : 'OPEN');
  const lot = document.getElementById('robotLot'); if (lot) lot.value = st.lot;
  const tp = document.getElementById('robotTp'); if (tp) tp.value = st.tp;
}

/* ---------------- audit ---------------- */
function renderAudit() {
  const tb = document.getElementById('auditBody');
  if (!tb) return;
  const rows = S.audit.slice(-200).reverse();
  tb.innerHTML = rows.length ? rows.map(a => `
    <tr><td class="mono">${stamp(a.ts)}</td><td>${esc(a.operator)} <span class="chip info">${esc(a.role)}</span></td>
    <td>${esc(a.action)}</td><td>${esc(a.detail)}</td><td class="mono">${esc(a.node)}</td></tr>`).join('')
    : '<tr><td colspan="5" class="empty">Audit trail is empty.</td></tr>';
  set('auditCount', S.audit.length);
}

/* ---------------- helpers ---------------- */
function set(id, val, html) {
  const el = document.getElementById(id);
  if (!el) return;
  if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
    if (document.activeElement !== el) el.value = String(val).replace(/<[^>]*>/g, '');
    return;
  }
  if (html) el.innerHTML = val; else el.textContent = val;
}

/* ---------------- client actions ---------------- */
function clientMoney(account, sign) {
  if (ro()) return;
  const c = S.clients.find(x => x.account === account);
  if (!c) return;
  openModal((sign > 0 ? 'Credit' : 'Debit') + ' Internal Wallet — ' + c.holder, [
    { label: 'Amount (USD)', type: 'number', step: '0.01', placeholder: '0.00' },
    { label: 'Narration', placeholder: 'Reason for adjustment', required: false }
  ], v => {
    const amt = r2(v[0]);
    if (!(amt > 0)) return toast('Enter a valid amount.', 'er');
    if (sign < 0 && amt > c.balance) return toast('Debit exceeds client balance.', 'er');
    c.balance = r2(c.balance + sign * amt);
    post({ type: sign > 0 ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT', from: sign > 0 ? 'EXTERNAL' : 'CLIENT', to: sign > 0 ? 'CLIENT' : 'EXTERNAL', amount: amt, note: (v[1] || 'Manual adjustment') + ' · ' + c.account });
    audit(sign > 0 ? 'CLIENT_CREDIT' : 'CLIENT_DEBIT', c.account + ' · ' + usd(amt));
    save(); renderClients(); renderOverview(); toast('Client wallet updated.', 'ok');
  });
}

function clientExt(account) {
  if (ro()) return;
  const c = S.clients.find(x => x.account === account);
  if (!c) return;
  openModal('External Wallet — ' + c.holder, [
    { label: 'Bank Name', placeholder: 'Beneficiary bank' },
    { label: 'Account Number', placeholder: 'Account number' },
    { label: 'Account Name', placeholder: 'Resolved name' },
    { label: 'Amount (USD)', type: 'number', step: '0.01', placeholder: '0.00' }
  ], v => {
    const amt = r2(v[3]);
    if (!(amt > 0)) return toast('Enter a valid amount.', 'er');
    if (amt > c.balance) return toast('Amount exceeds client internal balance.', 'er');
    c.balance = r2(c.balance - amt);
    S.settlements.push(makeSettlement({ from: 'client', amount: amt, bank: v[0], acctNo: v[1], acctName: v[2], method: 'SWIFT', swift: '', note: 'Client external transfer ' + c.account, status: 'PENDING' }));
    audit('CLIENT_EXTERNAL', c.account + ' · ' + usd(amt) + ' → ' + v[0]);
    save(); renderClients(); renderBank(); toast('External instruction queued for approval.', 'ok');
  });
}

function clientProfile(account) {
  const c = S.clients.find(x => x.account === account);
  if (!c) return;
  openModal('Edit Profile — ' + c.account, [
    { label: 'Holder Name', value: c.holder },
    { label: 'Email', value: c.email || '', required: false },
    { label: 'Passport / ID', value: c.passport || '', required: false },
    { label: 'Origin (Country / State)', value: c.origin || '' },
    { label: 'Linked IP / API / Protocol', value: c.node || '', required: false }
  ], v => {
    c.holder = v[0]; c.email = v[1]; c.passport = v[2]; c.origin = v[3]; c.node = v[4];
    audit('CLIENT_PROFILE', c.account + ' profile updated');
    save(); renderClients(); toast('Profile saved.', 'ok');
  });
}

function clientStatus(account) {
  if (ro()) return;
  const c = S.clients.find(x => x.account === account);
  if (!c) return;
  c.status = c.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
  audit('CLIENT_STATUS', c.account + ' → ' + c.status);
  save(); renderClients(); toast('Account ' + c.status.toLowerCase() + '.', c.status === 'ACTIVE' ? 'ok' : 'er');
}

function openAddClient() {
  if (ro()) return;
  openModal('Open Client Account', [
    { label: 'Holder Name', placeholder: 'Full legal name' },
    { label: 'Email', type: 'email', placeholder: 'client@email.com' },
    { label: 'Passport / ID Number', placeholder: 'Travel document', required: false },
    { label: 'Origin (Country / State)', placeholder: 'Country / State' },
    { label: 'Access Node / Public IP', placeholder: 'IP, API or protocol', required: false }
  ], v => {
    const account = 'GP' + String(Math.floor(10000000 + Math.random() * 89999999));
    const key = 'kp' + Math.random().toString(36).slice(2, 8);
    const pin = String(Math.floor(100000 + Math.random() * 899999));
    const c = {
      account, holder: v[0], email: v[1], passport: v[2], origin: v[3], node: v[4] || 'unlinked',
      ip: '0.0.0.0', key, pin, balance: 0, status: 'ACTIVE', createdAt: nowISO(), lastSeen: null, lastNode: null
    };
    S.clients.push(c);
    audit('CLIENT_OPEN', account + ' · ' + c.holder);
    save(); renderClients();
    openModal('Account Issued — ' + account, [
      { label: 'Access Key (share securely)', value: key },
      { label: 'Security PIN', value: pin },
      { label: 'Account Number', value: account }
    ], () => {});
    toast('Client account opened.', 'ok');
  });
}

/* ---------------- wallet / node actions ---------------- */
function openAddWallet() {
  if (ro()) return;
  openModal('Add Deposit Address', [
    { label: 'Network', placeholder: 'e.g. Arbitrum, Base, TON' },
    { label: 'Label', placeholder: 'Purpose of this address' },
    { label: 'Address', placeholder: 'Wallet address' }
  ], v => {
    if (!S.deposits) S.deposits = defaultDeposits();
    S.deposits.push({ network: v[0], label: v[1], address: v[2] });
    audit('WALLET_ADD', v[0] + ' · ' + v[1]);
    save(); renderWallets(); toast('Deposit address added.', 'ok');
  });
}

function openAddNode() {
  if (ro()) return;
  openModal('Add Network Link Slot', [
    { label: 'Label', placeholder: 'e.g. Access Bank API' },
    { label: 'Kind', type: 'select', options: ['EVM RPC', 'Bank API', 'Market API', 'Capital Market', 'IP / PVN', 'Webhook URL'] },
    { label: 'Endpoint / IP', placeholder: 'https:// or 10.0.0.1' },
    { label: 'Chain / Protocol Code', placeholder: 'e.g. 8453, GPB-2' },
    { label: 'API Key / Token', placeholder: 'Optional credential', required: false }
  ], v => {
    const n = { id: 'N' + (S.nodes.length + 1), label: v[0], kind: v[1], url: v[2], chain: v[3] || 'CUSTOM', status: 'provisioned', key: v[4] || '' };
    S.nodes.push(n);
    audit('NODE_ADD', n.id + ' · ' + n.label + ' · ' + n.url);
    save(); renderNodes(); toast('Link slot ' + n.id + ' provisioned.', 'ok');
  });
}

function probeNode(id) {
  const n = S.nodes.find(x => x.id === id);
  if (!n) return;
  const ms = 18 + Math.floor(Math.random() * 90);
  logLine('nodeLog', n.id + ' ' + n.label + ' — handshake OK · ' + ms + 'ms · ' + (n.chain || 'CUSTOM'), 'ok');
  toast(n.id + ' responded in ' + ms + 'ms.', 'ok');
}

function copyText(t) {
  try { navigator.clipboard.writeText(t); toast('Copied to clipboard.', 'ok'); }
  catch (e) { toast('Copy unavailable in this context.', 'er'); }
}

/* ---------------- payment link ---------------- */
function generatePayLink() {
  if (ro()) return;
  const name = document.getElementById('plName').value.trim() || 'Global Pilgrim';
  const amt = r2(document.getElementById('plAmt').value);
  const phone = document.getElementById('plPhone').value.trim();
  const purpose = document.getElementById('plPurpose').value.trim();
  if (!(amt > 0)) return toast('Enter the amount to collect.', 'er');
  const token = 'GPP-' + hash(name + amt + Date.now()).slice(0, 12);
  const url = location.origin + location.pathname + '?pay=' + token;
  const out = document.getElementById('payLinkOut');
  out.innerHTML = `<div class="receipt">
    <div class="rc-row"><span>Payee</span><b>${esc(name)}</b></div>
    <div class="rc-row"><span>Amount</span><b>${usd(amt)}</b></div>
    <div class="rc-row"><span>Purpose</span><b>${esc(purpose || 'General payment')}</b></div>
    <div class="rc-row"><span>Contact</span><b>${esc(phone)}</b></div>
    <div class="rc-row"><span>Reference</span><b>${esc(token)}</b></div>
    <div style="margin-top:10px;word-break:break-all;color:#e8c65a">${esc(url)}</div>
    <div class="sig">No account number is exposed. Settlement is routed through the Global Pilgrim master wallet and reconciled by reference.</div>
  </div>`;
  audit('PAY_LINK', token + ' · ' + usd(amt));
  toast('Secure payment link generated.', 'ok');
}

/* ---------------- settings actions ---------------- */
function toggleSetting(key, el) {
  if (ro()) return;
  S.settings[key] = !S.settings[key];
  el.classList.toggle('on', S.settings[key]);
  audit('SETTING', key + ' → ' + S.settings[key]);
  save();
}

function saveSettings() {
  if (ro()) return;
  const id = document.getElementById('setId').value.trim();
  const key = document.getElementById('setKey').value;
  const pin = document.getElementById('setPin').value.trim();
  const fee = Number(document.getElementById('setFee').value);
  if (!id) return toast('Operator ID cannot be empty.', 'er');
  if (pin && !/^\d{6}$/.test(pin)) return toast('PIN must be six digits.', 'er');
  if (!(fee >= 0 && fee < 10)) return toast('Fee must be between 0 and 10 percent.', 'er');
  S.auth.id = id;
  if (key) S.auth.key = key;
  if (pin) S.auth.pin = pin;
  S.auth.fee = fee;
  S.auth.customized = true;
  audit('CREDENTIALS', 'Operator credentials updated');
  save(); renderSettings();
  document.getElementById('setKey').value = '';
  document.getElementById('setPin').value = '';
  toast('Credentials saved. Use them at next sign-in.', 'ok');
}

/* ---------------- data custody ---------------- */
function download(name, text, mime) {
  const blob = new Blob([text], { type: mime || 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}

function exportBackup() {
  download('global-pilgrim-vault-' + Date.now() + '.json', JSON.stringify(S, null, 2));
  audit('EXPORT_BACKUP', 'Vault exported');
  toast('Vault exported.', 'ok');
}

function importBackup(e) {
  if (ro()) return;
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const d = JSON.parse(r.result);
      /* merge only — nothing is deleted or overwritten with less data */
      ['ledger', 'audit', 'clients', 'settlements', 'receipts', 'signals', 'alarms', 'cameras', 'nodes', 'positions'].forEach(k => {
        if (Array.isArray(d[k])) {
          if (!Array.isArray(S[k])) S[k] = [];
          const seen = new Set(S[k].map(x => JSON.stringify(x)));
          d[k].forEach(x => { if (!seen.has(JSON.stringify(x))) S[k].push(x); });
        }
      });
      if (d.wallets) Object.keys(d.wallets).forEach(k => {
        if (S.wallets[k] == null) S.wallets[k] = 0;
        S.wallets[k] = Math.max(S.wallets[k], Number(d.wallets[k]) || 0);
      });
      if (d.mining) { S.mining.pending = Math.max(S.mining.pending, Number(d.mining.pending) || 0); S.mining.settled = Math.max(S.mining.settled, Number(d.mining.settled) || 0); }
      audit('IMPORT_BACKUP', 'Vault merged from ' + f.name);
      save(); renderAll(); toast('Vault merged. Nothing was removed.', 'ok');
    } catch (err) { toast('That file is not a valid vault.', 'er'); }
    e.target.value = '';
  };
  r.readAsText(f);
}

function exportAudit() {
  const head = 'Timestamp,Operator,Role,Action,Detail,Node\n';
  const rows = S.audit.map(a => [stamp(a.ts), a.operator, a.role, a.action, a.detail, a.node]
    .map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(',')).join('\n');
  download('global-pilgrim-audit-' + Date.now() + '.csv', head + rows, 'text/csv');
  toast('Audit exported.', 'ok');
}

function printReceipt() {
  const last = S.settlements[S.settlements.length - 1];
  if (!last) return toast('No receipt has been issued yet.', 'er');
  const w = window.open('', '_blank');
  w.document.write('<html><head><title>' + last.serial + '</title><style>body{font-family:ui-monospace,monospace;padding:40px;color:#111}table{width:100%;border-collapse:collapse}td{padding:6px 0;border-bottom:1px solid #ddd}h2{margin:0}</style></head><body><h2>Global Pilgrim Bank</h2><p>Autonomous Settlement Notice</p>' +
    receiptHtml(last).replace(/<div class="stamp">[\s\S]*?<\/div>/, '') + '</body></html>');
  w.document.close(); w.focus(); setTimeout(() => w.print(), 350);
}

/* ---------------- credential + invoice generators ---------------- */
function genCredentials(id) {
  if (ro()) return;
  const n = S.nodes.find(x => x.id === id);
  if (!n) return;
  const apiKey = 'gp_' + hash(id + n.label + Date.now()).toLowerCase() + hash(String(Math.random())).toLowerCase().slice(0, 10);
  const ip = [10, Math.floor(Math.random() * 200), Math.floor(Math.random() * 250), Math.floor(Math.random() * 250) + 2].join('.');
  const proto = 'GPB/' + (n.chain || 'CUSTOM') + '/v' + (1 + Math.floor(Math.random() * 3));
  n.apiKey = apiKey; n.ip = ip; n.protocol = proto;
  audit('CREDENTIALS_ISSUE', n.id + ' · ' + proto + ' · ' + ip);
  save(); renderNodes();
  openModal('Credentials Issued — ' + n.id, [
    { label: 'API Key', value: apiKey },
    { label: 'Assigned IP / PVN', value: ip },
    { label: 'Protocol', value: proto }
  ], () => {});
  toast('Credentials generated for ' + n.id + '.', 'ok');
}

function generateInvoice() {
  if (ro()) return;
  const name = document.getElementById('plName').value.trim() || 'Global Pilgrim';
  const amt = r2(document.getElementById('plAmt').value);
  const purpose = document.getElementById('plPurpose').value.trim();
  if (!(amt > 0)) return toast('Enter the invoice amount.', 'er');
  const inv = 'INV-' + new Date().getFullYear() + '-' + String(S.settlements.length + 1).padStart(4, '0');
  const ref = 'GPP-' + hash(inv + amt).slice(0, 10);
  const out = document.getElementById('payLinkOut');
  out.innerHTML = `<div class="receipt">
    <div class="rc-head"><div><b>Global Pilgrim Bank</b><div style="font-size:9.5px;color:#6f7c93">COMMERCIAL INVOICE</div></div><div style="text-align:right"><b>${esc(inv)}</b><div style="font-size:9.5px;color:#6f7c93">${stamp(new Date())}</div></div></div>
    <div class="rc-row"><span>Bill To</span><b>${esc(name)}</b></div>
    <div class="rc-row"><span>Product / Service</span><b>${esc(purpose || 'General supply')}</b></div>
    <div class="rc-row"><span>Invoice Amount</span><b>${usd(amt)}</b></div>
    <div class="rc-row"><span>Payment Reference</span><b>${esc(ref)}</b></div>
    <div class="rc-row"><span>Pay Via</span><b>Secure payment link — no account number required</b></div>
    <div class="rc-row"><span>Beneficiary</span><b>Olawale Abdul-ganiyu Adeshina</b></div>
    <div class="sig">Settle against the reference above. Funds route through the Global Pilgrim master wallet and reconcile automatically. Contact globalpilgrimautonomous@gmail.com / +2349030277275.</div>
  </div>`;
  audit('INVOICE', inv + ' · ' + usd(amt));
  toast('Invoice ' + inv + ' generated.', 'ok');
}

/* ---------------- main-balance routing ---------------- */
function moveToMain(kind) {
  if (ro()) return;
  const bal = r2(S.wallets[kind] || 0);
  if (!(bal > 0)) return toast('Nothing to move from ' + (WALLET_LABELS[kind] || kind) + '.', 'er');
  const note = kind === 'profit'
    ? 'Profit realised from live Forex and capital-market trading — moved to Main Balance'
    : 'Transfer from ' + (WALLET_LABELS[kind] || kind) + ' to Main Balance';
  post({ type: 'INTERNAL_TRANSFER', from: kind, to: 'main', amount: bal, note });
  audit('MOVE_MAIN', usd(bal) + ' from ' + kind);
  save(); renderWallets(); renderOverview(); renderTrading();
  toast(usd(bal) + ' moved to Main Balance.', 'ok');
}

/* ---------------- deployment seal ---------------- */
function sealNow() {
  setReadOnly(true, true);
  audit('SEAL_ON', 'Deployment sealed read-only on this browser');
  save();
  set('sealState', 'sealed'); set('sealMode', 'READ-ONLY');
  toast('Deployment sealed. No records can be changed here.', 'er');
}
function unsealNow() {
  setReadOnly(false, true);
  set('sealState', 'open'); set('sealMode', 'OPEN');
  toast('Deployment unsealed. Full control restored.', 'ok');
}
function copySealedLink() {
  const url = location.origin + location.pathname + '#sealed';
  copyText(url);
}
